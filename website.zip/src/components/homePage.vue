<template>
  <div class="homePage">
    <!-- 安全产品 -->
    <div class="securityProduct">
      <div class="securiptProductTop">
        <div class="securipTproductTopLeft">
          <span
            >蛮犀资讯
            &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;《工业和信息化部337号令》解读</span
          >
        </div>
        <div class="securipTproductTopRight">
          <router-link class="more" to="/">更多>></router-link>
        </div>
      </div>
      <div class="securiptProductContainer">
        <h3>安全产品</h3>
        <div class="container">
          <ul v-for="(item, index) in securityProductList" :key="index">
            <!--     <div class="decorate"></div> -->
            <img src="../assets/icon.png" class="decorate" />
            <li>
              <span>{{ item[0].name }}</span>
            </li>
            <li v-for="(item, index) in item" :key="index">
              <router-link class="left" to="/" title="点击查看详情">{{
                item.name
              }}</router-link>
              <!-- <router-link class="right" to="/">查看详情>></router-link> -->
            </li>
          </ul>
        </div>
      </div>
    </div>
    <!-- 解决方案 -->
    <div class="solution">
      <h3>解决方案</h3>
      <div class="container">
        <ul>
          <li v-for="(item, index) in solutionList" :key="index">
            <img
              :src="item.imgSrc"
              @mouseover="zoom($event)"
              @mouseout="recover($event)"
            /><span>{{ item.name }}</span>
          </li>
        </ul>
      </div>
    </div>
    <!-- 荣誉资质 -->
    <div class="honor">
      <h3>荣誉资质</h3>
      <div class="container">
        <ul>
          <el-row>
            <img src="../assets/honor_02.png" title="中华人民共和国公安部"/>
            <img src="../assets/honor_03.png" title="湖北省公安厅"/>
            <img src="../assets/honor_04.png" title="深圳市公安局"/>
            <img src="../assets/honor_05.png" title="武汉市公安局"/>
            <img src="../assets/honor_06.png" title="南宁市公安局"
          /></el-row>
          <el-row>
            <img src="../assets/honor_08.png" title="国家信息中心"/>
            <img src="../assets/honor_09.png" title="国家互联网应急中心"/>
            <img src="../assets/honor_10.png" title="公安部第三研究所"/>
            <img src="../assets/honor_11.png" title="深圳市信息安全评测中心"/>
            <img src="../assets/honor_12.png" title="深圳市电子教务资源中心"
          /></el-row>
          <el-row>
            <img src="../assets/honor_13.png" title="国家信息中心"/>
            <img src="../assets/honor_14.png" title="广东省国家税务局"/>
            <img src="../assets/honor_15.png" title="国家超级计算深圳中心"/>
            <img src="../assets/honor_16.png" title="深圳市南山区人民政府"/>
            <img src="../assets/honor_17.png" title="中国信息安全测评中心"
          /></el-row>
        </ul>
      </div>
    </div>
    <!-- 宣传 -->
    <div class="publicity">
      <div class="publicityContent">
        <div class="publicityContentColumn">
          <h3 class="publicityContentColumnNumber">100%</h3>
          <p>覆盖企业移动化生命周期</p>
        </div>
        <div class="publicityContentColumn">
          <h3 class="publicityContentColumnNumber">10万+</h3>
          <p>管理移动设备</p>
        </div>
        <div class="publicityContentColumn">
          <h3 class="publicityContentColumnNumber">2000+</h3>
          <p>服务的客户</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import $ from "jquery";
export default {
  name: "homePage",
  data() {
    return {
      securityProductList: [
        [
          { id: 0, name: "移动应用安全评测" },
          { id: 1, name: "移动应用漏洞评测" },
          { id: 2, name: "移动应用合规评测" },
          { id: 3, name: "移动应用个人信息安全评测" },
          { id: 4, name: "移动应用持续监督" }
        ],
        [
          { id: 0, name: "移动应用安全防护" },
          { id: 1, name: "应用程序安全加固" },
          {
            id: 2,
            name: "应用代码源保护"
          },
          {
            id: 3,
            name: "应用数据资源保护"
          },
          {
            id: 4,
            name: "用户交互信息保护"
          }
        ],
        [
          { id: 0, name: "移动应用安全业务" },
          { id: 1, name: "通信数据保护" },
          { id: 2, name: "程序密钥保护" },
          { id: 3, name: "业务落地数据保护" },
          { id: 4, name: "设备环境自查" }
        ]
      ],
      solutionList: [
        { id: 1, name: "金融", imgSrc: require("../assets/solution1.jpg") },
        { id: 2, name: "政府", imgSrc: require("../assets/solution2.jpg") },
        { id: 3, name: "企业", imgSrc: require("../assets/solution2.jpg") }
      ]
    };
  },
  methods: {
    zoom(e) {
      $(e.target).css({ width: "500px", transition: "width 0.5s" });
    },
    recover(e) {
      $(e.target).css({ width: "" });
    }
  },
  mounted() {
    console.log(this.securityProductList);
  }
};
</script>
<style>
/* 安全产品 */
.securipTproductTopLeft {
  float: left;
}
.securipTproductTopRight {
  float: right;
}
.securiptProductTop:after {
  content: "";
  display: block;
  clear: both;
}
.securiptProductTop {
  margin-top: 10px;
  padding: 20px;
  font-size: 16px;
  background: #f5f5f5;
  color: #7c7c7c;
  font-weight: 600;
}
.securipTproductTopRight .more {
  color: inherit;
}
.securiptProductContainer h3,
.solution h3,
.honor h3 {
  font-size: 34px;
  color: #2b2b2b;
  text-align: center;
  margin: 20px 0;
  font-weight: 500;
}
.securiptProductContainer {
  background: url("../assets/section-bg.jpg") center;
  padding: 20px 0;
}
.securiptProductContainer h3 {
  color: white;
}
.securiptProductContainer .container {
  padding: 20px;
  margin: 20px;
  display: flex;
  justify-content: space-around;
}
.securiptProductContainer .container a {
  font-size: 18px;
}
.honor .container img {
  width: 220px;
}
.securiptProductContainer ul {
  width: 400px;
  padding: 20px;
  /* box-shadow: 0px 0px 10px #00000030; */
  box-sizing: border-box;
  border-radius: 10px;
  background: white;
}
.securiptProductContainer ul .decorate {
  display: block;
  margin: 0 auto;
}
.securiptProductContainer ul li {
  margin: 30px 0;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.securiptProductContainer ul li > span {
  color: #2b2b2b;
  font-weight: 700;
  font-family: -apple-system, system-ui, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif;
  font-size: 22px;
  margin: 0 auto;
}
.securiptProductContainer ul li:not(:first-child) {
  display: flex;
  justify-content: space-between;
}
.el-icon-mobile-phone {
  color: rgb(78, 186, 212);
  margin-right: 5px;
}
.securiptProductContainer a {
  margin: 0 auto;
}
/* 解决方案 */
.solution {
  margin-top: 40px;
}
.solution .container ul {
  display: flex;
  justify-content: space-around;
  padding: 20px;
}
.solution .container ul li {
  width: 400px;
  height: 615px;
  color: white;
  position: relative;
  overflow: hidden;
}
.solution .container ul li img {
  width: 400px;
  cursor: pointer;
}
.solution .container ul li span {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 22px;
  font-weight: 500;
}
/* 荣誉资质 */
.honor {
  padding: 20px;
}
.honor .container {
  width: 1200px;
  margin: 20px auto;
  text-align: center;
}
.honor img {
  margin-right: 5px;
}
/* 宣传 */
.publicity {
  height: 300px;
  background-image: url("../assets/data_bg.svg");
  background-size: cover;
  background-position: bottom center;
  display: flex;
  align-items: center;
  text-align: center;
}
.publicityContent {
  width: 70%;
  margin: 0 auto;
  color: white;
  display: flex;
  justify-content: space-between;
  align-content: center;
}
.publicityContentColumnNumber {
  font-size: 48px;
  font-weight: 500;
}
.publicityContentColumn {
  flex-basis: 30%;
  border-right: 1px solid rgba(255, 255, 255, 0.5);
}
.publicityContentColumn > p {
  color: #00f0ff;
  font-size: 16px;
  margin-top: 10px;
}
</style>
